class Rapports {
	
	Date date
	String type
	String statut

    static constraints = {
		date(nullable:false)
		type(nullable:false)
		statut(nullable:true)
    }
}
