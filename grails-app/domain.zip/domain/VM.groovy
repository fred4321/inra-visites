class VM {
	
	Date date
	String lieu
	Date dateConvoc
	String statut
	String refMedecin
	String avis
	boolean apte
	String conclusion
	Date dateEnvoisCourrierAgent
	Date dateEnvoisCourrierDURRH
	String natureVM
	
	static belongsTo = [agent : Agent, bs : BS]
	static hasMany = [observation : Observation]
	
	

    static constraints = {
		date(nullable:false)
		lieu(nullable:false)
		dateConvoc(nullable:false)
		statut(nullable:false)
		refMedecin(nullable:false)
		avis(nullable:true)
		apte(nullable:true)
		conclusion(nullable:true)
		dateEnvoisCourrierAgent(nullable:true)
		dateEnvoisCourrierDURRH(nullable:true)
		natureVM(nullable:true)
		observation(nullable:true)
		
    }
}
