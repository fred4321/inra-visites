class Observation {

	String observation
	
    static constraints = {
		observation(nullable:false)
    }
}
