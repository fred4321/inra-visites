class BS {
		
		String lieu
		String type
		boolean absent
		Date datePrescription
		Date dateConvocation
		Date datePassage
		String heureDebut
		String heureFin
		
		static belongsTo = [agent : Agent]
		static hasMany = [observation : Observation]

    static constraints = {
		lieu(nullable:false)
		type(nullable:false)
		absent(nullable:true)
		datePrescription(nullable:false)
		dateConvocation(nullable:true)
		datePassage(nullable:true)
		heureDebut(nullable:false)
		heureFin(nullable:false)
		observation(nullable:true)
    }
}
