class Unite {
	
	String groupe
	String nom
	
	static hasMany = [agent : Agent]

    static constraints = {
		groupe(nullable:true)
		nom(nullable:false)
    }
}
