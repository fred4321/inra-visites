class Agent {
	
	String matricule
	String nom
	String prenom
	Date dateNaissance
	String lieuNaissance
	String nationalite
	String site
	String courriel
	String genre
	Date dateArretTravail
	String departement
	String posteTravail
	String periodicite
	String libEmploi
	String insee
	String groupe
	boolean archive
	
	static belongsTo = [unite : Unite]
	static hasMany = [vm : VM, bs : BS]

    static constraints = {
		matricule(nullable:false)
		nom(nullable:false)
		prenom(nullable:false)
		dateNaissance(blank:false)
		lieuNaissance(nullable:false)
		nationalite(nullable:false)
		site(nullable:false)
		courriel(nullable:false, email:true)
		genre(nullable:false)
		dateArretTravail(nullable:true)
		departement(nullable:false)
		posteTravail(nullable:true)
		periodicite(nullable:true)
		libEmploi(nullable:true)
		insee(nullable:false)
		groupe(nullable:false)
		archive(nullable:true)
		
    }
}
