class User {
	
	String identifiant
	String password
	String profil
	String email

    static constraints = {
		identifiant(nullable:false)
		password(nullable:false)
		profil(nullable:false)
		email(nullable:false, email:true)
    }
}
