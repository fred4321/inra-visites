class Journaux {
	
	String type
	Date date
	Integer numFiche
	
	static belongsTo = [user : User]
	
    static constraints = {
		type(nullable:false)
		date(nullable:false)
		numFiche(nullable:false)
    }
}
