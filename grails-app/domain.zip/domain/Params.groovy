class Params {
	
	String groupe
	String valeur
	String info1
	String info2
	String info3
	String info4

    static constraints = {
		groupe(nullable:false)
		valeur(nullable:false)
		info1(nullable:true)
		info2(nullable:true)
		info3(nullable:true)
		info4(nullable:true)
    }
}
